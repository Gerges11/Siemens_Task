module.exports = {
    url: 'http://automationpractice.multiformis.com/index.php',
    elements: {
      searchBox: '#search_query_top',
      searchButton: 'button[name="submit_search"]',
      productList: '.product_list'
    }
  };
  